$(function () {
    "use strict";

    const projectDetails = {
        aquapoint: {
            title: "Aquapoint Monitoring",
            description: "A responsive water-monitoring dashboard that brings sensor data into a clear operational view. The concept includes live EC, pH, ammonia, dissolved oxygen, and temperature readings, alert thresholds, historical charts, and analytics.",
            role: "Full-stack development · Dashboard UI",
            tech: "PHP, MySQL, jQuery, AJAX, Bootstrap, ESP8266"
        },
        orqueue: {
            title: "OR Queue Display",
            description: "A patient queue management experience with a TV-friendly status board and an administration interface. Queue ordering, live status updates, and clear visual hierarchy help staff and visitors understand what is happening.",
            role: "Full-stack development · Queue workflow",
            tech: "PHP, MySQL, jQuery, AJAX, Bootstrap"
        },
        smartmed: {
            title: "SMARTMED Dispenser",
            description: "A connected medication dispenser interface combining medication schedules, chamber stock levels, alerts, and vital-sign monitoring. The project connects a web application with a microcontroller and a Python bridge.",
            role: "Application development · IoT integration",
            tech: "PHP, MySQL, Python, ESP32, Arduino, Chart.js"
        },
        ordinance: {
            title: "Ordinance Manager",
            description: "A document workflow system for managing ordinances and resolutions from receipt through referral, committee reporting, and approval. It includes document uploads, status tracking, activity logs, and notification concepts.",
            role: "Full-stack development · Workflow design",
            tech: "PHP, MySQL, jQuery, AJAX, Bootstrap"
        },
        clinic: {
            title: "Clinic Companion",
            description: "An Android application concept supporting clinic staff workflows, patient information, queue monitoring, and diagnosis records. The mobile experience communicates with a PHP-based backend API.",
            role: "Android development · API integration",
            tech: "Kotlin, Android Studio, PHP, MySQL, REST API"
        }
    };

    // Reveal elements as they enter the viewport.
    const revealObserver = new IntersectionObserver(function (entries, observer) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add("is-visible");
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12 });

    $(".reveal").each(function () {
        revealObserver.observe(this);
    });

    // Animate the small scroll progress indicator.
    function updateScrollProgress() {
        const scrollable = document.documentElement.scrollHeight - window.innerHeight;
        const progress = scrollable > 0 ? (window.scrollY / scrollable) * 100 : 0;
        $("#scrollProgress").css("width", progress + "%");
    }
    $(window).on("scroll", updateScrollProgress);
    updateScrollProgress();

    // Highlight the navigation link for the current section.
    const sections = $("main section[id]");
    $(window).on("scroll", function () {
        let current = "home";
        sections.each(function () {
            if (window.scrollY >= $(this).offset().top - 160) {
                current = this.id;
            }
        });
        $(".nav-link").removeClass("active");
        $('.nav-link[href="#' + current + '"]').addClass("active");
    });

    // Close the mobile navigation after selecting a section.
    $(".navbar-nav .nav-link").on("click", function () {
        $(".navbar-collapse").collapse("hide");
    });

    // Project category filters.
    $(".filter-btn").on("click", function () {
        const filter = $(this).data("filter");
        $(".filter-btn").removeClass("active");
        $(this).addClass("active");

        $(".project-item").each(function () {
            const categories = String($(this).data("category"));
            const shouldShow = filter === "all" || categories.split(" ").includes(filter);
            $(this).toggleClass("is-hidden", !shouldShow);
        });
    });

    // Project details modal.
    const projectModal = new bootstrap.Modal(document.getElementById("projectModal"));
    $(".project-link").on("click", function () {
        const project = projectDetails[$(this).data("project")];
        if (!project) return;

        $("#modalTitle").text(project.title);
        $("#modalDescription").text(project.description);
        $("#modalRole").text(project.role);
        $("#modalTech").text(project.tech);
        projectModal.show();
    });

    // Count-up statistics, triggered once.
    let countersStarted = false;
    const counterObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting && !countersStarted) {
                countersStarted = true;
                $(".counter").each(function () {
                    const element = $(this);
                    const target = Number(element.data("count"));
                    $({ value: 0 }).animate({ value: target }, {
                        duration: 1400,
                        easing: "swing",
                        step: function () {
                            element.text(Math.ceil(this.value) + (target === 100 ? "%" : "+"));
                        },
                        complete: function () {
                            element.text(target + (target === 100 ? "%" : "+"));
                        }
                    });
                });
            }
        });
    }, { threshold: 0.35 });

    const stats = document.querySelector(".stats-grid");
    if (stats) counterObserver.observe(stats);

    // Skill bars animate when the skills section becomes visible.
    let skillsAnimated = false;
    const skillObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting && !skillsAnimated) {
                skillsAnimated = true;
                $(".skill-track span").each(function () {
                    $(this).css("width", $(this).data("width"));
                });
            }
        });
    }, { threshold: 0.25 });

    const skillSection = document.querySelector("#skills");
    if (skillSection) skillObserver.observe(skillSection);

    // Theme preference is stored locally in the browser.
    const savedTheme = localStorage.getItem("portfolio-theme");
    if (savedTheme === "light") {
        $("body").addClass("light-theme");
        $("#themeToggle").html('<i class="fa-solid fa-sun"></i>');
    }

    $("#themeToggle").on("click", function () {
        $("body").toggleClass("light-theme");
        const isLight = $("body").hasClass("light-theme");
        localStorage.setItem("portfolio-theme", isLight ? "light" : "dark");
        $(this).html(isLight
            ? '<i class="fa-solid fa-sun"></i>'
            : '<i class="fa-solid fa-moon"></i>');
    });

    // Contact form builds a mailto link; no backend is required.
    $("#contactForm").on("submit", function (event) {
        event.preventDefault();

        const name = $("#contactName").val().trim();
        const email = $("#contactEmail").val().trim();
        const message = $("#contactMessage").val().trim();

        if (!name || !email || !message) return;

        const subject = encodeURIComponent("Portfolio inquiry from " + name);
        const body = encodeURIComponent(
            "Name: " + name + "\nEmail: " + email + "\n\n" + message
        );

        window.location.href = "mailto:hello@example.com?subject=" + subject + "&body=" + body;
    });

    $("#currentYear").text(new Date().getFullYear());
});
